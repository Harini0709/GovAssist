# Exam Compass

Exam Compass is a locally runnable exam-preparation coach: student accounts and profiles, exam discovery and tracking, a dynamically dated study plan, persisted quizzes and progress, notifications, weekly summaries, and a contextual chat with document upload and retrieval.

The included exam catalogue and practice questions are **illustrative sample data**, not current official recruitment notices. Current dates are deliberately unset. Always confirm eligibility, dates, application links, and notices with the recruiting authority. Rows are marked unverified in the API.

## Requirements

- Python 3.10 or later
- Node.js 20 or later
- npm

## Backend setup (Windows)

From the project root:

```powershell
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn main:app --reload
```

The API is available at `http://localhost:8000`; interactive Swagger documentation is at `http://localhost:8000/docs`. The database is created and seeded on first start.

## Frontend

In another terminal, from the project root:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. Copy `frontend/.env.example` to `frontend/.env` and set `VITE_API_URL` if the API is hosted somewhere other than `http://localhost:8000/api`.

## Environment variables

Copy the root `.env.example` to `.env` and set `SECRET_KEY` to a long, random value before deployment. If left empty for local development, the backend creates and persists a private random key at `backend/.secret_key`. The backend loads the root `.env` (or `backend/.env`) on startup. Never commit secrets or the generated key.

- `DATABASE_URL`: SQLite URL for local use; the data layer uses SQLite-compatible SQL and can be adapted to PostgreSQL.
- `SECRET_KEY`: signs the expiring bearer tokens.
- `CORS_ORIGINS`: comma-separated allowed frontend origins.
- `AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL`, `AI_BASE_URL`: optional OpenAI-compatible chat-completions configuration. Without these, the app and persisted core features continue to work with a concise local coaching fallback.
- `UPLOAD_DIR`: private local upload storage.

## Database and data

SQLite database initialization, schema creation, and clearly unverified sample catalogue/question seeding run automatically at API startup. By default the database is `backend/exam_compass.db`. Keep the database and `backend/uploads/` private; they may contain personal profiles and documents.

Uploaded PDF, DOCX, and text files are extracted, stored per user, chunked, and indexed in SQLite FTS for relevant chat retrieval. Image uploads are safely stored; OCR/vision analysis is not enabled without a configured vision-capable AI integration. Max upload size is 10 MB.

## Data and feature boundaries

- The bundled exam catalogue and question pool are illustrative, unverified seed data. The PYQ-style pool is not represented as a verified historical paper, and the mock test is a short practice set rather than a full official-length exam.
- No live government notice/date feed is configured. Deadline and exam reminders run only for tracked records explicitly marked verified; blank dates remain blank.
- Document retrieval currently uses per-user SQLite full-text search and chunking. FAISS/pgvector embeddings are not bundled.
- Image uploads are sent to the configured chat-completions endpoint only when it is enabled; choose a vision-capable model. There is no local OCR.
- Admin exam creation is available through an admin-protected API endpoint; a separate admin web console and broader exam-editing workflow are not included.

## Architecture

```text
React + TypeScript + Tailwind (frontend)
             │ REST / bearer auth
FastAPI (backend/main.py)
   ├── SQLite: users, profiles, exams, plans, tasks, attempts, chats, documents
   ├── `backend/ai/`: matching, study/adaptive planning, readiness, chat, file extraction and FTS retrieval
   └── Optional AI provider + per-user FTS document retrieval
```

Student passwords are PBKDF2-HMAC-SHA256 hashed with per-password salts. API routes scope personal records to the authenticated user. The minimal admin exam-create endpoint requires a user whose database role is explicitly set to `admin`; regular registrations never grant this role. Do not expose this local SQLite/admin setup as a production deployment without proper operational hardening.

## Main API routes

- `POST /api/auth/register`, `POST /api/auth/login`
- `GET/PUT /api/users/profile`
- `GET /api/exams`, `GET /api/exams/{id}`, `POST /api/exams/match`
- `POST/GET /api/tracker`, `DELETE /api/tracker/{exam_id}`
- `POST /api/study-plan/generate`, `GET /api/study-plan/{exam_id}`, `POST /api/study-plan/update`
- `GET /api/quiz`, `POST /api/quiz/submit`; `/api/pyq` and `/api/mock` routes are also available
- `GET /api/progress`, `GET /api/progress/weekly`, `GET /api/readiness`
- `GET /api/notifications`, `POST /api/notifications/read`
- `POST /api/chat`, `GET /api/chat/history`, `GET /api/chat/{session_id}`
- `POST /api/upload/{image|pdf|document}`

## Tests

Run the backend integration tests from `backend/`:

```powershell
python -m unittest -v test_api
```

Build-check the frontend from `frontend/`:

```powershell
npm run build
```

## Troubleshooting

- **Frontend cannot reach API:** start the backend on port 8000 and keep the frontend origin in `CORS_ORIGINS`.
- **`python` or `npm` is not found:** install Python/Node.js and reopen the terminal so PATH refreshes.
- **Invalid login:** passwords require at least eight characters at registration; use the email address in lowercase/uppercase as entered.
- **No exam dates shown:** the bundled catalogue intentionally has no fabricated dates. Official live notices have not been imported.
- **AI chat is general:** configure the optional provider settings in the backend process and restart it. Core features do not require an API key.
- **Uploaded PDF has no extracted text:** scanned/image-only PDFs need OCR, which is not bundled. Text-based PDFs and DOCX/TXT are supported.
- **Reset local development data:** stop the backend and remove only `backend/exam_compass.db` when you explicitly want to clear local accounts and progress. Back up user data first.

## ZIP-ready handoff

The project is self-contained in this directory. Exclude local `.env` files, virtual environments, `node_modules`, SQLite databases, and user uploads from any distributable ZIP. Include `.env.example`, source, and this README.
