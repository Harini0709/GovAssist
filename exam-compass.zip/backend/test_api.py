import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from fastapi.testclient import TestClient

import main


class ExamCompassFlowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        main.DB_PATH = str(Path(self.temp.name) / "test.db")
        main.UPLOAD_DIR = Path(self.temp.name) / "uploads"
        main.UPLOAD_DIR.mkdir()
        main.initialize()
        self.client = TestClient(main.app)
        response = self.client.post("/api/auth/register", json={
            "name": "Test Student", "email": "student@example.com", "password": "safe-password-123"
        })
        self.assertEqual(response.status_code, 200, response.text)
        self.token = response.json()["access_token"]
        self.headers = {"Authorization": f"Bearer {self.token}"}

    def tearDown(self) -> None:
        self.client.close()
        self.temp.cleanup()

    def test_coach_flow_persists_progress_and_chat(self) -> None:
        profile = self.client.put("/api/users/profile", headers=self.headers, json={"data": {
            "name": "Test Student", "dob": "2000-01-01", "qualification": "Bachelor's degree",
            "study_hours": 2, "weak_subjects": ["Quantitative Aptitude"],
            "target_date": (date.today() + timedelta(days=10)).isoformat()
        }})
        self.assertEqual(profile.status_code, 200)

        matches = self.client.post("/api/exams/match", headers=self.headers)
        self.assertEqual(matches.status_code, 200)
        exam = matches.json()[0]
        self.assertFalse(exam["verified"])

        tracked = self.client.post("/api/tracker", headers=self.headers, json={"exam_id": exam["id"]})
        self.assertEqual(tracked.status_code, 200)
        plan = self.client.post("/api/study-plan/generate", headers=self.headers, json={"exam_id": exam["id"]})
        self.assertEqual(plan.status_code, 200, plan.text)
        self.assertTrue(plan.json()["tasks"])
        task = plan.json()["tasks"][0]
        update = self.client.post("/api/study-plan/update", headers=self.headers, json={
            "task_id": task["id"], "status": "completed"
        })
        self.assertEqual(update.status_code, 200)

        quiz = self.client.get(f"/api/quiz?exam_id={exam['id']}", headers=self.headers)
        self.assertEqual(quiz.status_code, 200)
        self.assertTrue(quiz.json())
        question = quiz.json()[0]
        result = self.client.post("/api/quiz/submit", headers=self.headers, json={
            "exam_id": exam["id"], "answers": {str(question["id"]): 99}, "kind": "quiz"
        })
        self.assertEqual(result.status_code, 200, result.text)
        self.assertEqual(result.json()["total"], 1)
        self.assertTrue(result.json()["weak_subjects"])
        updated_plan = self.client.get(f"/api/study-plan/{exam['id']}", headers=self.headers).json()
        self.assertTrue(any(task["kind"] == "practice" for task in updated_plan["tasks"]))
        remaining_task = next(task for task in updated_plan["tasks"] if task["status"] == "pending")
        self.assertEqual(self.client.post("/api/study-plan/update", headers=self.headers, json={
            "task_id": remaining_task["id"], "status": "missed"
        }).status_code, 200)
        self.assertTrue(self.client.get("/api/notifications", headers=self.headers).json())
        self.assertIn("score", self.client.get("/api/readiness", headers=self.headers).json())

        chat = self.client.post("/api/chat", headers=self.headers, json={"message": "Explain percentages simply"})
        self.assertEqual(chat.status_code, 200, chat.text)
        self.assertIn("percentage", chat.json()["answer"].lower())
        session = chat.json()["session_id"]
        self.assertEqual(self.client.get(f"/api/chat/{session}", headers=self.headers).status_code, 200)
        self.assertTrue(self.client.get("/api/chat/history", headers=self.headers).json())

    def test_user_cannot_read_another_users_chat(self) -> None:
        session = self.client.post("/api/chat", headers=self.headers, json={"message": "Help me study"}).json()["session_id"]
        other = self.client.post("/api/auth/register", json={
            "name": "Other Student", "email": "other@example.com", "password": "safe-password-123"
        }).json()["access_token"]
        response = self.client.get(f"/api/chat/{session}", headers={"Authorization": f"Bearer {other}"})
        self.assertEqual(response.status_code, 404)

    def test_text_upload_is_saved_and_retrievable(self) -> None:
        response = self.client.post("/api/upload/document", headers=self.headers, files={
            "file": ("notes.txt", b"Percentages mean parts out of one hundred.", "text/plain")
        })
        self.assertEqual(response.status_code, 200, response.text)
        self.assertGreater(response.json()["extracted_characters"], 0)
        chat = self.client.post("/api/chat", headers=self.headers, json={"message": "What is in my uploaded notes?"})
        self.assertEqual(chat.status_code, 200, chat.text)

    def test_image_upload_is_scoped_and_vision_limit_is_explicit(self) -> None:
        response = self.client.post("/api/upload/image", headers=self.headers, files={
            "file": ("question.png", b"\x89PNG\r\n\x1a\nsample-image-data", "image/png")
        })
        self.assertEqual(response.status_code, 200, response.text)
        chat = self.client.post("/api/chat", headers=self.headers, json={"message": "Please explain my uploaded image"})
        self.assertIn("vision-capable AI model", chat.json()["answer"])

    def test_age_filter_uses_completed_years(self) -> None:
        self.client.put("/api/users/profile", headers=self.headers, json={"data": {
            "dob": "1980-01-01", "qualification": "Bachelor's degree"
        }})
        names = [exam["name"] for exam in self.client.post("/api/exams/match", headers=self.headers).json()]
        self.assertNotIn("SSC CGL", names)


if __name__ == "__main__":
    unittest.main()
