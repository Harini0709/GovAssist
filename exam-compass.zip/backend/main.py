from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterator

from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT.parent / ".env")
load_dotenv(ROOT / ".env")
from ai.adaptive_planner import next_available_day
from ai.chatbot import reply as modular_ai_reply
from ai.eligibility import age_on
from ai.multimodal import BadZipFile, ElementTree, PdfReadError, extract_text, validate_content_type
from ai.rag import chunks as chunk_text, match_expression
from ai.readiness import calculate_readiness
from ai.study_planner import plan_target

DB_PATH = os.getenv("DATABASE_URL", "sqlite:///./exam_compass.db").replace("sqlite:///", "")
if not Path(DB_PATH).is_absolute():
    DB_PATH = str((ROOT / DB_PATH).resolve())


def load_secret() -> str:
    configured = os.getenv("SECRET_KEY")
    if configured and configured != "replace-with-a-long-random-secret":
        return configured
    secret_path = ROOT / ".secret_key"
    try:
        with secret_path.open("x", encoding="utf-8") as secret_file:
            secret_file.write(secrets.token_urlsafe(48))
    except FileExistsError:
        pass
    except OSError:
        if secret_path.exists():
            return secret_path.read_text(encoding="utf-8").strip()
        raise RuntimeError("Set SECRET_KEY or provide writable backend storage for a generated local key.")
    return secret_path.read_text(encoding="utf-8").strip()


SECRET = load_secret()
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", str(ROOT / "uploads")))
if not UPLOAD_DIR.is_absolute():
    UPLOAD_DIR = (ROOT / UPLOAD_DIR).resolve()
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
app = FastAPI(title="Exam Compass API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
bearer = HTTPBearer(auto_error=False)


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def initialize() -> None:
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS profiles(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, data TEXT NOT NULL DEFAULT '{}');
        CREATE TABLE IF NOT EXISTS exams(id INTEGER PRIMARY KEY, name TEXT NOT NULL, organization TEXT, category TEXT, qualification TEXT, min_age INTEGER, max_age INTEGER, state TEXT, application_start TEXT, application_deadline TEXT, exam_date TEXT, notification_url TEXT, application_url TEXT, official_url TEXT, subjects TEXT, syllabus TEXT, pattern TEXT, verified INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS tracked_exams(user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, exam_id INTEGER REFERENCES exams(id) ON DELETE CASCADE, created_at TEXT NOT NULL, PRIMARY KEY(user_id, exam_id));
        CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, exam_id INTEGER REFERENCES exams(id) ON DELETE CASCADE, target_date TEXT, created_at TEXT NOT NULL, UNIQUE(user_id, exam_id));
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, plan_id INTEGER REFERENCES plans(id) ON DELETE CASCADE, day TEXT NOT NULL, subject TEXT NOT NULL, topic TEXT NOT NULL, minutes INTEGER NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', learned INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY, exam_id INTEGER, subject TEXT NOT NULL, topic TEXT NOT NULL, prompt TEXT NOT NULL, options TEXT NOT NULL, answer INTEGER NOT NULL, explanation TEXT NOT NULL, difficulty TEXT NOT NULL DEFAULT 'medium', kind TEXT NOT NULL DEFAULT 'quiz');
        CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, exam_id INTEGER, kind TEXT NOT NULL, score INTEGER NOT NULL, total INTEGER NOT NULL, minutes INTEGER NOT NULL DEFAULT 0, details TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, text TEXT NOT NULL, created_at TEXT NOT NULL, read INTEGER NOT NULL DEFAULT 0, UNIQUE(user_id,text));
        CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, title TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, chat_id INTEGER REFERENCES chats(id) ON DELETE CASCADE, role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, filename TEXT NOT NULL, storage_path TEXT, extracted_text TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE VIRTUAL TABLE IF NOT EXISTS knowledge USING fts5(user_id UNINDEXED, document_id UNINDEXED, chunk);
        """)
        plan_columns = {row["name"] for row in con.execute("PRAGMA table_info(plans)")}
        if "target_date" not in plan_columns:
            con.execute("ALTER TABLE plans ADD COLUMN target_date TEXT")
        document_columns = {row["name"] for row in con.execute("PRAGMA table_info(documents)")}
        if "storage_path" not in document_columns:
            con.execute("ALTER TABLE documents ADD COLUMN storage_path TEXT")
        if con.execute("SELECT COUNT(*) FROM exams").fetchone()[0] == 0:
            seed_exams(con)
        if con.execute("SELECT COUNT(*) FROM questions").fetchone()[0] == 0:
            seed_questions(con)


def seed_exams(con: sqlite3.Connection) -> None:
    data = [
        ("SSC CGL", "Staff Selection Commission", "Central / SSC", "Bachelor's degree", 18, 32, None, None, None, None, "https://ssc.gov.in", "https://ssc.gov.in", "Quantitative Aptitude, Reasoning, English, General Awareness", "Arithmetic; algebra; reasoning; English; general awareness", "Tiered computer-based examination"),
        ("UPSC Civil Services", "Union Public Service Commission", "Central / Civil Services", "Bachelor's degree", 21, 32, None, None, None, None, "https://upsc.gov.in", "https://upsconline.nic.in", "General Studies, CSAT, Essay, Optional", "Preliminary, mains and interview syllabus; verify current notification", "Prelims, mains and interview"),
        ("IBPS PO", "Institute of Banking Personnel Selection", "Banking", "Bachelor's degree", 20, 30, None, None, None, None, "https://www.ibps.in", "https://www.ibps.in", "Reasoning, Quantitative Aptitude, English, General Awareness", "Banking aptitude and general awareness; verify current notification", "Preliminary, mains and interview"),
        ("RRB NTPC", "Railway Recruitment Boards", "Railway", "12th pass or bachelor's degree (post-dependent)", 18, 33, None, None, None, None, "https://www.rrbcdg.gov.in", "https://www.rrbcdg.gov.in", "Mathematics, Reasoning, General Awareness", "Post-specific; verify current official notification", "Computer-based tests; post-dependent"),
        ("CTET", "Central Board of Secondary Education", "Teaching", "Teacher-training qualification (level-dependent)", 18, None, None, None, None, None, "https://ctet.nic.in", "https://ctet.nic.in", "Child Development, Languages, Mathematics, Environmental Studies", "Paper I / Paper II syllabus; verify current bulletin", "Computer-based eligibility test"),
        ("UP Police Constable", "Uttar Pradesh Police Recruitment and Promotion Board", "State / Police", "12th pass", 18, 25, "Uttar Pradesh", None, None, None, "https://uppbpb.gov.in", "https://uppbpb.gov.in", "General Knowledge, Hindi, Numerical Ability, Reasoning", "State recruitment rules and syllabus vary by notification", "Written and physical tests; verify current notice"),
        ("LIC AAO", "Life Insurance Corporation of India", "Insurance", "Bachelor's degree", 21, 30, None, None, None, None, "https://licindia.in", "https://licindia.in", "Reasoning, Quantitative Aptitude, English, General Awareness", "Verify current recruitment notification", "Preliminary, mains and interview"),
        ("AFCAT", "Indian Air Force", "Defence", "Degree requirements vary by branch", 20, 26, None, None, None, None, "https://afcat.cdac.in", "https://afcat.cdac.in", "General Awareness, Verbal Ability, Numerical Ability, Reasoning", "Branch-specific degree and age conditions; verify current notification", "Online test and selection process"),
        ("State PSC Combined Services", "Respective State Public Service Commission", "State Government", "Bachelor's degree (varies)", 21, 40, None, None, None, None, None, None, "General Studies, State-specific subjects", "State-specific; official information unavailable until a commission is selected", "Varies by state and notification"),
    ]
    con.executemany("INSERT INTO exams(name,organization,category,qualification,min_age,max_age,state,application_start,application_deadline,exam_date,official_url,application_url,subjects,syllabus,pattern,verified) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)", data)


def seed_questions(con: sqlite3.Connection) -> None:
    rows = [
        (1, "Quantitative Aptitude", "Percentages", "What is 25% of 240?", ["40", "50", "60", "80"], 2, "25% is one quarter; 240 ÷ 4 = 60.", "easy", "quiz"),
        (1, "Quantitative Aptitude", "Percentages", "A value rises from 80 to 100. What is the percentage increase?", ["20%", "25%", "30%", "40%"], 1, "The increase is 20; 20 ÷ 80 × 100 = 25%.", "easy", "quiz"),
        (1, "Reasoning", "Number series", "Choose the next number: 3, 6, 12, 24, ...", ["30", "36", "48", "42"], 2, "Each term is doubled, so the next number is 48.", "easy", "quiz"),
        (1, "English", "Grammar", "Choose the grammatically correct sentence.", ["She have completed the work.", "She has completed the work.", "She completing the work.", "She complete the work."], 1, "Use 'has' with the third-person singular subject 'she'.", "easy", "quiz"),
        (1, "General Awareness", "Civics", "Which part of the Constitution contains the Fundamental Rights?", ["Part II", "Part III", "Part IV", "Part V"], 1, "Fundamental Rights are contained in Part III.", "easy", "pyq"),
        (1, "Quantitative Aptitude", "Time and work", "A person completes a job in 10 days. What fraction is completed in one day at a constant rate?", ["1/5", "1/10", "1/20", "10"], 1, "At a constant rate, one day's work is 1 divided by 10, or 1/10.", "easy", "pyq"),
        (1, "Reasoning", "Analogy", "Book is to reading as fork is to:", ["drawing", "writing", "eating", "cutting"], 2, "A book is used for reading; a fork is used for eating.", "easy", "pyq"),
        (1, "Quantitative Aptitude", "Ratio", "If 2:3 is equivalent to x:12, what is x?", ["6", "8", "9", "10"], 1, "Scale both ratio terms by 4: 2 × 4 = 8 and 3 × 4 = 12.", "medium", "quiz"),
    ]
    rows = [r[:4] + (json.dumps(r[4]),) + r[5:] for r in rows]
    con.executemany("INSERT INTO questions(exam_id,subject,topic,prompt,options,answer,explanation,difficulty,kind) VALUES(?,?,?,?,?,?,?,?,?)", rows)


@app.on_event("startup")
def startup() -> None:
    initialize()


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240_000)
    return f"{salt.hex()}${derived.hex()}"


def check_password(password: str, stored: str) -> bool:
    try:
        salt, expected = stored.split("$", 1)
        return hmac.compare_digest(hash_password(password, bytes.fromhex(salt)).split("$", 1)[1], expected)
    except (ValueError, TypeError):
        return False


def token_for(user_id: int) -> str:
    payload = f"{user_id}:{int(time.time()) + 60 * 60 * 24 * 7}"
    signature = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}:{signature}"


def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict[str, Any]:
    if not credentials:
        raise HTTPException(401, "Please sign in to continue.")
    try:
        uid, expires, signature = credentials.credentials.split(":")
        payload = f"{uid}:{expires}"
        expected = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if int(expires) < time.time() or not hmac.compare_digest(signature, expected):
            raise ValueError
        with db() as con:
            user = con.execute("SELECT id,email,name,role FROM users WHERE id=?", (int(uid),)).fetchone()
        if not user:
            raise ValueError
        return dict(user)
    except (ValueError, TypeError):
        raise HTTPException(401, "Your session has expired. Please sign in again.")


def row_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None


def exam_dict(row: sqlite3.Row) -> dict[str, Any]:
    result = dict(row)
    for key in ("subjects", "syllabus"):
        result[key] = result[key].split(", ") if result.get(key) else []
    result["verified"] = bool(result["verified"])
    return result


def days_until(value: str | None) -> int | None:
    if not value:
        return None
    try:
        return (date.fromisoformat(value) - date.today()).days
    except ValueError:
        return None


class Credentials(BaseModel):
    email: str
    password: str = Field(min_length=8, max_length=128)
    name: str | None = None


class ProfilePayload(BaseModel):
    data: dict[str, Any]


class ExamPayload(BaseModel):
    exam_id: int


class TaskPayload(BaseModel):
    status: str = "completed"


class QuizPayload(BaseModel):
    exam_id: int
    answers: dict[int, int]
    kind: str = "quiz"
    minutes: int = 0


class ChatPayload(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    session_id: int | None = None


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/api/auth/register")
def register(body: Credentials) -> dict[str, Any]:
    email = body.email.strip().lower()
    if "@" not in email or len(email) > 254:
        raise HTTPException(422, "Enter a valid email address.")
    with db() as con:
        try:
            cur = con.execute("INSERT INTO users(email,name,password,created_at) VALUES(?,?,?,?)",
                              (email, (body.name or email.split("@")[0]).strip()[:80], hash_password(body.password), utc_now()))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "An account with this email already exists.")
        uid = cur.lastrowid
        con.execute("INSERT INTO profiles(user_id,data) VALUES(?, '{}')", (uid,))
    return {"access_token": token_for(uid), "token_type": "bearer", "user": {"id": uid, "email": email, "name": body.name or email.split("@")[0]}}


@app.post("/api/auth/login")
def login(body: Credentials) -> dict[str, Any]:
    with db() as con:
        user = con.execute("SELECT * FROM users WHERE email=?", (body.email.strip().lower(),)).fetchone()
    if not user or not check_password(body.password, user["password"]):
        raise HTTPException(401, "Email or password is incorrect.")
    return {"access_token": token_for(user["id"]), "token_type": "bearer", "user": {"id": user["id"], "email": user["email"], "name": user["name"]}}


@app.get("/api/users/profile")
def get_profile(user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        profile = con.execute("SELECT data FROM profiles WHERE user_id=?", (user["id"],)).fetchone()
    return {"user": user, "profile": json.loads(profile["data"]) if profile else {}}


@app.put("/api/users/profile")
def update_profile(body: ProfilePayload, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        con.execute("UPDATE profiles SET data=? WHERE user_id=?", (json.dumps(body.data), user["id"]))
        if body.data.get("name"):
            con.execute("UPDATE users SET name=? WHERE id=?", (str(body.data["name"])[:80], user["id"]))
    return {"profile": body.data, "saved": True}


@app.get("/api/exams")
def list_exams(user: dict = Depends(current_user)) -> list[dict[str, Any]]:
    with db() as con:
        return [exam_dict(r) for r in con.execute("SELECT * FROM exams ORDER BY name")]


@app.get("/api/exams/{exam_id}")
def get_exam(exam_id: int, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        row = con.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Exam not found.")
    exam = exam_dict(row)
    exam["application_days_left"] = days_until(exam.get("application_deadline"))
    exam["exam_days_left"] = days_until(exam.get("exam_date"))
    return exam


@app.post("/api/exams/match")
def match_exams(user: dict = Depends(current_user)) -> list[dict[str, Any]]:
    with db() as con:
        profile_row = con.execute("SELECT data FROM profiles WHERE user_id=?", (user["id"],)).fetchone()
        exams = [exam_dict(r) for r in con.execute("SELECT * FROM exams")]
    profile = json.loads(profile_row["data"]) if profile_row else {}
    age = None
    try:
        age = age_on(profile.get("dob", ""))
    except (ValueError, TypeError, AttributeError):
        pass
    education = (profile.get("qualification") or "").lower()
    state = (profile.get("state") or "").lower()
    matches = []
    for exam in exams:
        reasons = []
        if exam["min_age"] is not None and age is not None and age < exam["min_age"]:
            continue
        if exam["max_age"] is not None and age is not None and age > exam["max_age"]:
            continue
        if exam["state"] and state and exam["state"].lower() != state:
            continue
        qualification = (exam.get("qualification") or "").lower()
        if "bachelor" in qualification and education and not any(w in education for w in ("bachelor", "graduate", "degree", "master", "postgraduate")):
            continue
        if age is not None and exam["min_age"] is not None and (exam["max_age"] is None or age <= exam["max_age"]):
            reasons.append("Your age appears within the listed range")
        if education:
            reasons.append("Education profile considered")
        if not reasons:
            reasons.append("Review the official notice to confirm personal eligibility")
        matches.append({**exam, "match": min(98, 72 + len(reasons) * 8), "reasons": reasons})
    return matches


@app.post("/api/tracker")
def track_exam(body: ExamPayload, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        if not con.execute("SELECT 1 FROM exams WHERE id=?", (body.exam_id,)).fetchone():
            raise HTTPException(404, "Exam not found.")
        con.execute("INSERT OR IGNORE INTO tracked_exams(user_id,exam_id,created_at) VALUES(?,?,?)",
                    (user["id"], body.exam_id, utc_now()))
    return {"tracked": True}


@app.get("/api/tracker")
def tracked_exams(user: dict = Depends(current_user)) -> list[dict[str, Any]]:
    with db() as con:
        rows = con.execute("""SELECT e.*,p.id plan_id FROM tracked_exams t JOIN exams e ON e.id=t.exam_id
                            LEFT JOIN plans p ON p.exam_id=e.id AND p.user_id=t.user_id WHERE t.user_id=?""", (user["id"],)).fetchall()
        results = []
        for row in rows:
            exam = exam_dict(row)
            exam["days_left"] = days_until(exam.get("exam_date"))
            exam["preparation"] = 0
            if row["plan_id"]:
                counts = con.execute("SELECT COUNT(*) total,SUM(status='completed') done FROM tasks WHERE plan_id=?", (row["plan_id"],)).fetchone()
                exam["preparation"] = round((counts["done"] or 0) * 100 / counts["total"]) if counts["total"] else 0
            results.append(exam)
        return results


@app.delete("/api/tracker/{exam_id}")
def untrack_exam(exam_id: int, user: dict = Depends(current_user)) -> dict[str, bool]:
    with db() as con:
        con.execute("DELETE FROM tracked_exams WHERE user_id=? AND exam_id=?", (user["id"], exam_id))
        con.execute("DELETE FROM plans WHERE user_id=? AND exam_id=?", (user["id"], exam_id))
    return {"tracked": False}


def build_plan(con: sqlite3.Connection, user_id: int, exam_id: int) -> int:
    exam = con.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    if not exam:
        raise HTTPException(404, "Exam not found.")
    prof = con.execute("SELECT data FROM profiles WHERE user_id=?", (user_id,)).fetchone()
    profile = json.loads(prof["data"]) if prof else {}
    end = plan_target(exam["exam_date"] or profile.get("target_date"))
    days = (end - date.today()).days
    hours = max(0.5, min(12, float(profile.get("study_hours") or 2)))
    subjects = [s.strip() for s in (exam["subjects"] or "General Awareness").split(",")]
    con.execute("INSERT OR IGNORE INTO plans(user_id,exam_id,target_date,created_at) VALUES(?,?,?,?)",
                (user_id, exam_id, end.isoformat(), datetime.now(timezone.utc).isoformat()))
    plan = con.execute("SELECT id FROM plans WHERE user_id=? AND exam_id=?", (user_id, exam_id)).fetchone()
    plan_id = plan["id"]
    if con.execute("SELECT COUNT(*) FROM tasks WHERE plan_id=?", (plan_id,)).fetchone()[0]:
        return plan_id
    weak = {s.lower() for s in profile.get("weak_subjects", [])}
    minutes_per_day = int(hours * 60 * 0.78)
    learning_days = max(1, int(days * 0.65))
    topic_map = {
        "Quantitative Aptitude": ["Percentages", "Ratio and proportion", "Time and work", "Data interpretation"],
        "Reasoning": ["Number series", "Analogy", "Coding-decoding", "Logical puzzles"],
        "English": ["Grammar", "Reading comprehension", "Vocabulary", "Error detection"],
        "General Awareness": ["Polity basics", "Modern history", "Geography revision", "Current affairs"],
    }
    today = date.today()
    for offset in range(days):
        day = today + timedelta(days=offset)
        if offset >= learning_days:
            kind = "revision" if offset < days * 0.85 else "mock"
            topic = "Revision and practice" if kind == "revision" else "Sectional mock and review"
            subject = "Mixed practice"
            duration = min(minutes_per_day, 60 if kind == "mock" else 40)
        else:
            subject = sorted(subjects, key=lambda s: (s.lower() not in weak, (offset + subjects.index(s)) % max(1, len(subjects))))[offset % len(subjects)]
            topics = topic_map.get(subject, [f"{subject} fundamentals", f"{subject} practice"])
            topic = topics[(offset // max(1, len(subjects))) % len(topics)]
            kind, duration = "learn", max(20, minutes_per_day // 2)
        con.execute("INSERT INTO tasks(plan_id,day,subject,topic,minutes,kind) VALUES(?,?,?,?,?,?)",
                    (plan_id, day.isoformat(), subject, topic, duration, kind))
    return plan_id


@app.post("/api/study-plan/generate")
def generate_plan(body: ExamPayload, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        if not con.execute("SELECT 1 FROM tracked_exams WHERE user_id=? AND exam_id=?", (user["id"], body.exam_id)).fetchone():
            raise HTTPException(400, "Track this exam before creating its study plan.")
        plan_id = build_plan(con, user["id"], body.exam_id)
    return get_plan(body.exam_id, user)


@app.get("/api/study-plan/{exam_id}")
def get_plan(exam_id: int, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        plan = con.execute("SELECT id FROM plans WHERE user_id=? AND exam_id=?", (user["id"], exam_id)).fetchone()
        if not plan:
            raise HTTPException(404, "No plan yet. Generate a plan to get started.")
        tasks = [dict(r) for r in con.execute("SELECT * FROM tasks WHERE plan_id=? AND day>=? ORDER BY day,id", (plan["id"], date.today().isoformat()))]
        today_tasks = [t for t in tasks if t["day"] == date.today().isoformat()]
        dates = con.execute("""SELECT COALESCE(e.exam_date,p.target_date) target_date FROM plans p
                             JOIN exams e ON e.id=p.exam_id WHERE p.id=?""", (plan["id"],)).fetchone()
        return {"exam_id": exam_id, "remaining_days": days_until(dates["target_date"]), "tasks": tasks, "today": today_tasks}


def reschedule_missed_task(con: sqlite3.Connection, user_id: int, task: sqlite3.Row) -> None:
    profile_row = con.execute("SELECT data FROM profiles WHERE user_id=?", (user_id,)).fetchone()
    profile = json.loads(profile_row["data"]) if profile_row else {}
    daily_limit = int(max(.5, min(12, float(profile.get("study_hours") or 2))) * 60)
    target_day = next_available_day(
        con, task["plan_id"], max(date.today(), date.fromisoformat(task["day"]) + timedelta(days=1)),
        task["minutes"], daily_limit,
    )
    if target_day:
        con.execute(
            "INSERT INTO tasks(plan_id,day,subject,topic,minutes,kind) VALUES(?,?,?,?,?,?)",
            (task["plan_id"], target_day.isoformat(), task["subject"], task["topic"], task["minutes"], task["kind"]),
        )


@app.post("/api/study-plan/update")
def update_plan(body: dict[str, Any], user: dict = Depends(current_user)) -> dict[str, Any]:
    task_id = int(body.get("task_id", 0))
    status = body.get("status", "completed")
    if status not in ("completed", "missed", "pending"):
        raise HTTPException(422, "Invalid task status.")
    with db() as con:
        task = con.execute("SELECT t.*,p.user_id,p.exam_id FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE t.id=? AND p.user_id=?", (task_id, user["id"])).fetchone()
        if not task:
            raise HTTPException(404, "Study task not found.")
        con.execute("UPDATE tasks SET status=?, learned=? WHERE id=?", (status, status == "completed", task_id))
        if status == "missed":
            con.execute("INSERT OR IGNORE INTO notifications(user_id,text,created_at) VALUES(?,?,?)",
                        (user["id"], f"You missed {task['topic']}. Your plan is ready to adjust.", utc_now()))
            reschedule_missed_task(con, user["id"], task)
    return {"updated": True, "status": status}


def question_dict(r: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": r["id"],
        "subject": r["subject"],
        "topic": r["topic"],
        "prompt": r["prompt"],
        "options": json.loads(r["options"]),
        "difficulty": r["difficulty"],
        "kind": r["kind"],
        "source_label": "Illustrative sample; not a verified past-paper question." if r["kind"] == "pyq" else "Illustrative practice sample.",
    }


@app.get("/api/quiz")
@app.get("/api/pyq")
@app.get("/api/mock")
def get_quiz(request: Request, exam_id: int = 1, kind: str | None = None, user: dict = Depends(current_user)) -> list[dict[str, Any]]:
    kind = kind or ("pyq" if request.url.path.endswith("/pyq") else "mock" if request.url.path.endswith("/mock") else "quiz")
    if kind not in ("quiz", "pyq", "mock"):
        raise HTTPException(422, "Choose quiz, pyq, or mock.")
    with db() as con:
        rows = con.execute("SELECT * FROM questions WHERE kind=? AND (exam_id=? OR exam_id=1 OR exam_id IS NULL) ORDER BY RANDOM() LIMIT 10", (kind, exam_id)).fetchall()
        if not rows and kind == "mock":
            rows = con.execute("SELECT * FROM questions WHERE kind='quiz' AND (exam_id=? OR exam_id=1) ORDER BY RANDOM() LIMIT 10", (exam_id,)).fetchall()
        return [question_dict(r) for r in rows]


@app.post("/api/quiz/submit")
@app.post("/api/pyq/submit")
@app.post("/api/mock/submit")
def submit_quiz(body: QuizPayload, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        if body.kind not in ("quiz", "pyq", "mock"):
            raise HTTPException(422, "Invalid practice type.")
        rows = con.execute("SELECT * FROM questions WHERE id IN (%s)" % ",".join("?" * len(body.answers)), tuple(body.answers.keys())).fetchall() if body.answers else []
        if not rows:
            raise HTTPException(400, "Submit at least one answer.")
        correct = 0
        detail = []
        for row in rows:
            answer = body.answers.get(row["id"], -1)
            good = answer == row["answer"]
            correct += int(good)
            detail.append({"question_id": row["id"], "subject": row["subject"], "topic": row["topic"], "correct": good, "your_answer": answer, "answer": row["answer"], "explanation": row["explanation"]})
        con.execute("INSERT INTO attempts(user_id,exam_id,kind,score,total,minutes,details,created_at) VALUES(?,?,?,?,?,?,?,?)",
                    (user["id"], body.exam_id, body.kind, correct, len(rows), body.minutes, json.dumps(detail), utc_now()))
        missed_topics = [item["topic"] for item in detail if not item["correct"]]
        weak_subjects = list(dict.fromkeys(item["subject"] for item in detail if not item["correct"]))
        if missed_topics:
            plan = con.execute("SELECT id FROM plans WHERE user_id=? AND exam_id=?", (user["id"], body.exam_id)).fetchone()
            if plan:
                profile_row = con.execute("SELECT data FROM profiles WHERE user_id=?", (user["id"],)).fetchone()
                profile = json.loads(profile_row["data"]) if profile_row else {}
                daily_limit = int(max(.5, min(12, float(profile.get("study_hours") or 2))) * 60)
                practice_day = next_available_day(con, plan["id"], date.today() + timedelta(days=1), 20, daily_limit)
                if practice_day:
                    weak_topic = max(set(missed_topics), key=missed_topics.count)
                    weak_subject = next(item["subject"] for item in detail if item["topic"] == weak_topic and not item["correct"])
                    con.execute("INSERT INTO tasks(plan_id,day,subject,topic,minutes,kind) VALUES(?,?,?,?,20,'practice')",
                                (plan["id"], practice_day.isoformat(), weak_subject, f"Review {weak_topic}",))
                    con.execute("INSERT OR IGNORE INTO notifications(user_id,text,created_at) VALUES(?,?,?)",
                                (user["id"], f"Your plan now includes extra practice on {weak_topic}.", utc_now()))
        return {"score": correct, "total": len(rows), "accuracy": round(correct / len(rows) * 100), "weak_subjects": weak_subjects, "details": detail}


@app.get("/api/progress")
def progress(user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        attempts = con.execute("SELECT kind,SUM(score) score,SUM(total) total,COUNT(*) count FROM attempts WHERE user_id=? GROUP BY kind", (user["id"],)).fetchall()
        task_stats = con.execute("""SELECT COUNT(*) total,SUM(status='completed') completed,
                                  SUM(CASE WHEN status='completed' THEN minutes ELSE 0 END) minutes
                                  FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE p.user_id=?""", (user["id"],)).fetchone()
        return {"attempts": {r["kind"]: {"score": r["score"], "total": r["total"], "attempts": r["count"], "accuracy": round(r["score"] * 100 / r["total"]) if r["total"] else 0} for r in attempts},
                "tasks": {"total": task_stats["total"] or 0, "completed": task_stats["completed"] or 0, "minutes": task_stats["minutes"] or 0}}


@app.get("/api/readiness")
def readiness(user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        stats = con.execute("SELECT kind,SUM(score) score,SUM(total) total FROM attempts WHERE user_id=? GROUP BY kind", (user["id"],)).fetchall()
        by_kind = {r["kind"]: (r["score"] * 100 / r["total"] if r["total"] else 0) for r in stats}
        t = con.execute("""SELECT COUNT(*) total,SUM(status='completed') done FROM tasks x JOIN plans p ON p.id=x.plan_id WHERE p.user_id=?""", (user["id"],)).fetchone()
        score, covered = calculate_readiness(by_kind, t["done"] or 0, t["total"] or 0)
        return {"score": score, "label": "Getting started" if not stats else "Good progress" if score >= 65 else "Building momentum", "breakdown": {"quiz_accuracy": round(by_kind.get("quiz", 0)), "pyq_accuracy": round(by_kind.get("pyq", 0)), "mock_performance": round(by_kind.get("mock", 0)), "tasks_completed": round(covered)}}


@app.get("/api/progress/weekly")
def weekly_report(user: dict = Depends(current_user)) -> dict[str, Any]:
    since = (date.today() - timedelta(days=7)).isoformat()
    with db() as con:
        attempts = con.execute("SELECT SUM(score) score,SUM(total) total,COUNT(*) count FROM attempts WHERE user_id=? AND created_at>=?", (user["id"], since)).fetchone()
        tasks = con.execute("SELECT COUNT(*) completed,SUM(minutes) minutes FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE p.user_id=? AND t.status='completed' AND t.day>=?", (user["id"], since)).fetchone()
        missed = con.execute("SELECT COUNT(*) count FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE p.user_id=? AND t.status='missed' AND t.day>=?", (user["id"], since)).fetchone()["count"]
        weak = con.execute("""SELECT q.subject,COUNT(*) misses FROM attempts a,json_each(a.details) d
                            JOIN questions q ON q.id=json_extract(d.value,'$.question_id')
                            WHERE a.user_id=? AND a.created_at>=? AND json_extract(d.value,'$.correct')=0
                            GROUP BY q.subject ORDER BY misses DESC LIMIT 1""", (user["id"], since)).fetchone()
        return {"study_minutes": tasks["minutes"] or 0, "topics_completed": tasks["completed"] or 0, "questions_solved": attempts["total"] or 0,
                "accuracy": round(attempts["score"] * 100 / attempts["total"]) if attempts["total"] else 0,
                "missed_days": missed, "focus_next": weak["subject"] if weak else "Keep your daily routine"}


@app.get("/api/notifications")
def notifications(user: dict = Depends(current_user)) -> list[dict[str, Any]]:
    with db() as con:
        tracked = con.execute("""SELECT e.name,e.application_deadline,e.exam_date,e.verified
                               FROM tracked_exams t JOIN exams e ON e.id=t.exam_id WHERE t.user_id=?""",
                              (user["id"],)).fetchall()
        for exam in tracked:
            if not exam["verified"]:
                continue
            app_days = days_until(exam["application_deadline"])
            exam_days = days_until(exam["exam_date"])
            if app_days is not None and 0 <= app_days <= 7:
                text = f"{exam['name']} application closes in {app_days} day{'s' if app_days != 1 else ''}."
                con.execute("INSERT OR IGNORE INTO notifications(user_id,text,created_at) VALUES(?,?,?)",
                            (user["id"], text, utc_now()))
            if exam_days in (30, 15, 7, 1):
                text = f"{exam['name']} exam is in {exam_days} days."
                con.execute("INSERT OR IGNORE INTO notifications(user_id,text,created_at) VALUES(?,?,?)",
                            (user["id"], text, utc_now()))
        overdue = con.execute("""SELECT t.*,p.user_id FROM tasks t JOIN plans p ON p.id=t.plan_id
                               WHERE p.user_id=? AND t.day<? AND t.status='pending'""",
                              (user["id"], date.today().isoformat())).fetchall()
        for task in overdue:
            con.execute("UPDATE tasks SET status='missed' WHERE id=?", (task["id"],))
            con.execute("INSERT OR IGNORE INTO notifications(user_id,text,created_at) VALUES(?,?,?)",
                        (user["id"], f"You missed {task['topic']}. Your plan is ready to adjust.", utc_now()))
            reschedule_missed_task(con, user["id"], task)
        return [dict(r) for r in con.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 30", (user["id"],))]


@app.post("/api/notifications/read")
def read_notifications(user: dict = Depends(current_user)) -> dict[str, bool]:
    with db() as con:
        con.execute("UPDATE notifications SET read=1 WHERE user_id=?", (user["id"],))
    return {"read": True}


@app.post("/api/chat")
async def chat(body: ChatPayload, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        if body.session_id:
            chat_row = con.execute("SELECT * FROM chats WHERE id=? AND user_id=?", (body.session_id, user["id"])).fetchone()
            if not chat_row:
                raise HTTPException(404, "Chat not found.")
            chat_id = chat_row["id"]
        else:
            cur = con.execute("INSERT INTO chats(user_id,title,created_at) VALUES(?,?,?)", (user["id"], body.message[:60], utc_now()))
            chat_id = cur.lastrowid
        message_id = con.execute("INSERT INTO messages(chat_id,role,content,created_at) VALUES(?,?,?,?)",
                                 (chat_id, "user", body.message, utc_now())).lastrowid
        profile = con.execute("SELECT data FROM profiles WHERE user_id=?", (user["id"],)).fetchone()
        prof = json.loads(profile["data"]) if profile else {}
        match_query = match_expression(body.message)
        docs = []
        if match_query:
            docs = con.execute("SELECT chunk FROM knowledge WHERE user_id=? AND knowledge MATCH ? LIMIT 4",
                               (str(user["id"]), match_query)).fetchall()
        tracked = con.execute("SELECT e.name,e.exam_date FROM tracked_exams t JOIN exams e ON e.id=t.exam_id WHERE t.user_id=?", (user["id"],)).fetchall()
        next_tasks = con.execute("""SELECT t.day,t.subject,t.topic,t.minutes,t.kind FROM tasks t
                                 JOIN plans p ON p.id=t.plan_id WHERE p.user_id=? AND t.day>=?
                                 AND t.status='pending' ORDER BY t.day,t.id LIMIT 5""",
                                 (user["id"], date.today().isoformat())).fetchall()
        recent_attempts = con.execute(
            "SELECT kind,score,total,created_at,details FROM attempts WHERE user_id=? ORDER BY id DESC LIMIT 5",
            (user["id"],),
        ).fetchall()
        latest_image = con.execute(
            "SELECT storage_path,filename FROM documents WHERE user_id=? AND storage_path IS NOT NULL ORDER BY id DESC",
            (user["id"],),
        ).fetchall()
        image_paths = []
        for document in latest_image:
            if Path(document["filename"]).suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
                image_path = (UPLOAD_DIR / document["storage_path"]).resolve()
                if image_path.is_relative_to(UPLOAD_DIR.resolve()):
                    image_paths = [image_path]
                break
        context = (
            f"Student profile: {json.dumps(prof)}. "
            f"Tracked exams: {json.dumps([dict(r) for r in tracked])}. "
            f"Next pending plan tasks: {json.dumps([dict(r) for r in next_tasks])}. "
            f"Recent quiz/PYQ/mock attempts: {json.dumps([dict(r) for r in recent_attempts])}. "
            f"Relevant uploaded material: {' '.join(r['chunk'] for r in docs)}"
        )
        history = [dict(r) for r in con.execute("SELECT role,content FROM messages WHERE chat_id=? AND id<? ORDER BY id DESC LIMIT 8",
                                                 (chat_id, message_id)).fetchall()][::-1]
    answer = await modular_ai_reply(body.message, context, history, image_paths)
    with db() as con:
        con.execute("INSERT INTO messages(chat_id,role,content,created_at) VALUES(?,?,?,?)", (chat_id, "assistant", answer, utc_now()))
    return {"session_id": chat_id, "answer": answer}


@app.get("/api/chat/history")
def chat_history(user: dict = Depends(current_user)) -> list[dict[str, Any]]:
    with db() as con:
        return [dict(r) for r in con.execute("SELECT id,title,created_at FROM chats WHERE user_id=? ORDER BY id DESC", (user["id"],))]


@app.get("/api/chat/{session_id}")
def chat_session(session_id: int, user: dict = Depends(current_user)) -> dict[str, Any]:
    with db() as con:
        chat_row = con.execute("SELECT * FROM chats WHERE id=? AND user_id=?", (session_id, user["id"])).fetchone()
        if not chat_row:
            raise HTTPException(404, "Chat not found.")
        messages = [dict(r) for r in con.execute("SELECT role,content,created_at FROM messages WHERE chat_id=? ORDER BY id", (session_id,))]
        return {"id": session_id, "title": chat_row["title"], "messages": messages}


@app.post("/api/upload/{kind}")
async def upload_document(kind: str, file: UploadFile = File(...), user: dict = Depends(current_user)) -> dict[str, Any]:
    allowed = {".pdf", ".txt", ".docx", ".png", ".jpg", ".jpeg", ".webp"}
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in allowed:
        raise HTTPException(415, "Upload a PDF, text, DOCX, or image file.")
    content = await file.read(10 * 1024 * 1024 + 1)
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(413, "Files must be 10 MB or smaller.")
    if not validate_content_type(file.filename or "", content):
        raise HTTPException(415, "The file content does not match its extension.")
    text = ""
    try:
        text = extract_text(file.filename or suffix, content)[:200_000]
    except (PdfReadError, BadZipFile, KeyError, ElementTree.ParseError, OSError, ValueError) as exc:
        raise HTTPException(422, "We couldn't read this file. Try a text-based PDF or a supported document.") from exc
    filename = f"{user['id']}_{secrets.token_hex(12)}{suffix}"
    try:
        (UPLOAD_DIR / filename).write_bytes(content)
    except OSError as exc:
        raise HTTPException(500, "We couldn't store your upload. Check available storage and try again.") from exc
    indexed_chunks = chunk_text(text)
    with db() as con:
        cur = con.execute("INSERT INTO documents(user_id,filename,storage_path,extracted_text,created_at) VALUES(?,?,?,?,?)",
                          (user["id"], file.filename or filename, filename, text[:200_000], utc_now()))
        doc_id = cur.lastrowid
        con.executemany("INSERT INTO knowledge(user_id,document_id,chunk) VALUES(?,?,?)", [(str(user["id"]), str(doc_id), c) for c in indexed_chunks])
    return {"document_id": doc_id, "filename": file.filename, "extracted_characters": len(text), "message": "Uploaded and indexed for chat." if text else "File saved. Text could not be extracted; image analysis needs a configured vision provider."}


@app.post("/api/admin/exams")
def admin_create_exam(body: dict[str, Any], user: dict = Depends(current_user)) -> dict[str, Any]:
    if user["role"] != "admin":
        raise HTTPException(403, "Admin access required.")
    required = ("name", "organization", "category")
    if any(not body.get(k) for k in required):
        raise HTTPException(422, "Name, organization, and category are required.")
    with db() as con:
        cur = con.execute("""INSERT INTO exams(name,organization,category,qualification,min_age,max_age,state,application_start,application_deadline,exam_date,notification_url,application_url,official_url,subjects,syllabus,pattern,verified)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", tuple(body.get(k) for k in ("name","organization","category","qualification","min_age","max_age","state","application_start","application_deadline","exam_date","notification_url","application_url","official_url","subjects","syllabus","pattern")) + (int(bool(body.get("verified"))),))
        return {"id": cur.lastrowid}
