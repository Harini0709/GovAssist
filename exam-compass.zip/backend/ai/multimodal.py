import base64
from io import BytesIO
from pathlib import Path
from zipfile import BadZipFile, ZipFile
from xml.etree import ElementTree

from pypdf import PdfReader
from pypdf.errors import PdfReadError


def extract_text(filename: str, content: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix == ".pdf":
        return "\n".join(page.extract_text() or "" for page in PdfReader(BytesIO(content)).pages)
    if suffix == ".txt":
        return content.decode("utf-8", errors="replace")
    if suffix == ".docx":
        with ZipFile(BytesIO(content)) as archive:
            xml = ElementTree.fromstring(archive.read("word/document.xml"))
            return " ".join(node.text or "" for node in xml.iter() if node.tag.endswith("}t"))
    if suffix in {".png", ".jpg", ".jpeg", ".webp"}:
        return "Image uploaded. Image text extraction requires an AI vision provider."
    raise ValueError("Unsupported file type.")


def image_data_uri(path: Path, max_bytes: int = 5 * 1024 * 1024) -> str:
    content = path.read_bytes()
    if len(content) > max_bytes:
        raise ValueError("Image files larger than 5 MB cannot be sent to the AI provider.")
    mime = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}.get(path.suffix.lower())
    if not mime:
        raise ValueError("Unsupported image format.")
    return f"data:{mime};base64,{base64.b64encode(content).decode('ascii')}"


def validate_content_type(filename: str, content: bytes) -> bool:
    suffix = Path(filename).suffix.lower()
    signatures = {
        ".pdf": content.startswith(b"%PDF-"),
        ".png": content.startswith(b"\x89PNG\r\n\x1a\n"),
        ".jpg": content.startswith(b"\xff\xd8\xff"),
        ".jpeg": content.startswith(b"\xff\xd8\xff"),
        ".webp": len(content) >= 12 and content[:4] == b"RIFF" and content[8:12] == b"WEBP",
        ".docx": content.startswith(b"PK\x03\x04"),
    }
    if suffix in signatures:
        return signatures[suffix]
    return suffix == ".txt"


__all__ = ["extract_text", "image_data_uri", "validate_content_type", "BadZipFile", "ElementTree", "PdfReadError"]
