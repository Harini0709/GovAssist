import os
from pathlib import Path
from typing import Any

import httpx

from .prompts import SYSTEM_PROMPT, offline_reply
from .multimodal import image_data_uri


async def reply(
    prompt: str, context: str, history: list[dict[str, str]], image_paths: list[Path] | None = None
) -> str:
    provider = os.getenv("AI_PROVIDER", "").lower()
    key = os.getenv("AI_API_KEY", "")
    model = os.getenv("AI_MODEL", "")
    if provider and key and model:
        try:
            async with httpx.AsyncClient(timeout=25) as client:
                response = await client.post(
                    os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
                    + "/chat/completions",
                    headers={"Authorization": f"Bearer {key}"},
                    json={
                        "model": model,
                        "messages": [
                            {"role": "system", "content": f"{SYSTEM_PROMPT} {context}"},
                            *history,
                            {
                                "role": "user",
                                "content": [
                                    {"type": "text", "text": prompt},
                                    *[
                                        {"type": "image_url", "image_url": {"url": image_data_uri(path)}}
                                        for path in (image_paths or [])
                                    ],
                                ],
                            },
                        ],
                    },
                )
                response.raise_for_status()
                return response.json()["choices"][0]["message"]["content"]
        except (httpx.HTTPError, KeyError, ValueError):
            pass
    answer = offline_reply(prompt)
    if image_paths:
        answer += " To analyze the uploaded image, configure a vision-capable AI model."
    return answer
