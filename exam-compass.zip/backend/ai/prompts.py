SYSTEM_PROMPT = (
    "You are Exam Compass, a friendly Indian government exam preparation coach. "
    "Distinguish official verified information from guidance. Never invent exam dates "
    "or eligibility. Use the supplied student and retrieved-document context."
)


def offline_reply(prompt: str) -> str:
    lower = prompt.lower()
    if any(term in lower for term in ("today", "study plan", "what should i study")):
        return (
            "I couldn't reach the configured AI service, but your saved plan is available "
            "above. Start with the first pending task, then spend remaining time on the "
            "weakest subject shown in your recent practice."
        )
    if "percent" in lower:
        return (
            "A percentage means 'out of 100'. For example, 25% is 25 out of 100, or one "
            "quarter. To find 25% of 240, calculate 240 × 25 ÷ 100 = 60. Try converting "
            "common percentages into fractions to calculate faster."
        )
    return (
        "I’m here to help with your exam preparation. The external AI service is not "
        "configured right now, so I can offer general guidance: break the question into "
        "smaller steps, check your exam's official notification for dates and rules, and "
        "practise the topic with a short set of questions. Add an AI provider in the "
        "backend environment for tailored conversational answers."
    )
