from datetime import date


def age_on(dob: str, on_date: date | None = None) -> int:
    current = on_date or date.today()
    birth = date.fromisoformat(dob)
    return current.year - birth.year - ((current.month, current.day) < (birth.month, birth.day))
