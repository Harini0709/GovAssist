from datetime import date

from fastapi import HTTPException


def plan_target(target: str | None) -> date:
    if not target:
        raise HTTPException(
            400,
            "The official exam date is unavailable. Add your own preparation target date in your profile to build a timed plan.",
        )
    try:
        end = date.fromisoformat(target)
    except ValueError:
        raise HTTPException(422, "Enter a valid preparation target date in your profile.")
    days = (end - date.today()).days
    if days < 1:
        raise HTTPException(400, "Your preparation target date has passed. Update it in your profile to build a new plan.")
    if days > 730:
        raise HTTPException(422, "Choose a preparation target within the next two years.")
    return end
