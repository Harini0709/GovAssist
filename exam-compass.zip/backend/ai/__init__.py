"""AI and personalization components for Exam Compass."""
