import re


def match_expression(query: str, limit: int = 8) -> str:
    return " OR ".join(f'"{term}"' for term in re.findall(r"\w+", query.lower())[:limit])


def chunks(text: str, size: int = 800, overlap: int = 100) -> list[str]:
    clean = text[:200_000]
    step = max(1, size - overlap)
    return [clean[start:start + size] for start in range(0, len(clean), step) if clean[start:start + size].strip()]
