from datetime import date, timedelta
import sqlite3


def next_available_day(
    con: sqlite3.Connection,
    plan_id: int,
    start: date,
    task_minutes: int,
    daily_limit: int,
) -> date | None:
    for offset in range(730):
        target = start + timedelta(days=offset)
        booked = con.execute(
            "SELECT COALESCE(SUM(minutes),0) FROM tasks WHERE plan_id=? AND day=? AND status!='missed'",
            (plan_id, target.isoformat()),
        ).fetchone()[0]
        if booked + task_minutes <= daily_limit:
            return target
    return None
