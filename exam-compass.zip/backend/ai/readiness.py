def calculate_readiness(accuracy: dict[str, float], completed: int, total: int) -> tuple[int, float]:
    covered = completed * 100 / total if total else 0
    score = round(
        accuracy.get("quiz", 0) * .25
        + accuracy.get("pyq", 0) * .25
        + accuracy.get("mock", 0) * .25
        + covered * .25
    )
    return score, covered
